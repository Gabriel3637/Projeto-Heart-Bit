//
//  Model.swift
//  HeartBit
//
//  Created by Turma01-7 on 08/04/25.
//

import Foundation
