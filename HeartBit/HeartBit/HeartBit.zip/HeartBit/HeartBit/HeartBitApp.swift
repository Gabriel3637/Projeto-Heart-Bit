//
//  HeartBitApp.swift
//  HeartBit
//
//  Created by Turma01-7 on 08/04/25.
//

import SwiftUI

@main
struct HeartBitApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
